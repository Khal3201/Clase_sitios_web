﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Cafetería
{
    public partial class sesion_activa : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Session["usuario"] != null)
                {
                    lblBienvenida.Text = $"Bienvenido, {Session["usuario"]}";
                }
                else
                {
                    Response.Redirect("registro.aspx");
                }
            }
        }

        protected void btnCerrarSesion_Click(object sender, EventArgs e)
        {
            Session.Clear();      // Limpia todas las variables de sesión
            Session.Abandon();    // Abandona la sesión actual
            Response.Redirect("registro.aspx"); // Redirige al login/registro
        }

    }
}