﻿using System;
using System.Configuration;
using System.Data.SqlClient;
using System.Web.UI;

namespace Cafetería
{
    public partial class registro : Page
    {
        bool sesion = false;
        protected void Page_Load(object sender, EventArgs e)
        {
            // Aquí podrías cargar algo al inicio si lo necesitas
        }

        protected void btnRegistrar_Click(object sender, EventArgs e)
        {
            string nombre = txtNombre.Text.Trim();
            string correo = txtCorreo.Text.Trim();
            string contrasena = txtContrasena.Text.Trim();

            if (string.IsNullOrEmpty(nombre) || string.IsNullOrEmpty(correo) || string.IsNullOrEmpty(contrasena))
            {
                lblMensaje.Text = "Por favor, completa todos los campos.";
                lblMensaje.ForeColor = System.Drawing.Color.Red;
                return;
            }

            try
            {
                string connectionString = ConfigurationManager.ConnectionStrings["ConexionDB"].ConnectionString;

                using (SqlConnection conexion = new SqlConnection(connectionString))
                {
                    conexion.Open();

                    string query = "INSERT INTO usuarios (full_username, email, password) VALUES (@Nombre, @Correo, @Contrasena)";

                    using (SqlCommand cmd = new SqlCommand(query, conexion))
                    {
                        cmd.Parameters.AddWithValue("@Nombre", nombre);
                        cmd.Parameters.AddWithValue("@Correo", correo);
                        cmd.Parameters.AddWithValue("@Contrasena", contrasena);

                        cmd.ExecuteNonQuery();
                    }
                }

                lblMensaje.Text = "Usuario registrado exitosamente, por favor inicie sesión.";
                lblMensaje.ForeColor = System.Drawing.Color.Green;
                sesion = true;

                txtNombre.Text = "";
                txtCorreo.Text = "";
                txtContrasena.Text = "";
            }
            catch (Exception ex)
            {
                lblMensaje.Text = "Error al registrar: " + ex.Message;
                lblMensaje.ForeColor = System.Drawing.Color.Red;
            }
        }
        protected void btnLogin_Click(object sender, EventArgs e)
        {
            string correo = txtCorreoLogin.Text.Trim();
            string contrasena = txtContrasenaLogin.Text.Trim();

            if (string.IsNullOrEmpty(correo) || string.IsNullOrEmpty(contrasena))
            {
                lblMensaje.Text = "Por favor, ingresa correo y contraseña.";
                lblMensaje.ForeColor = System.Drawing.Color.Red;
                return;
            }

            try
            {
                string connectionString = ConfigurationManager.ConnectionStrings["ConexionDB"].ConnectionString;

                using (SqlConnection conexion = new SqlConnection(connectionString))
                {
                    conexion.Open();

                    string query = "SELECT full_username FROM usuarios WHERE email = @Correo AND password = @Contrasena";

                    using (SqlCommand cmd = new SqlCommand(query, conexion))
                    {
                        cmd.Parameters.AddWithValue("@Correo", correo);
                        cmd.Parameters.AddWithValue("@Contrasena", contrasena);

                        object resultado = cmd.ExecuteScalar();

                        if (resultado != null)
                        {
                            // Guardamos el usuario en sesión
                            Session["usuario"] = resultado.ToString();
                            // Redireccionamos a la página de sesión activa
                            Response.Redirect("sesion_activa.aspx");
                        }
                        else
                        {
                            lblMensaje.Text = "Correo o contraseña incorrectos.";
                            lblMensaje.ForeColor = System.Drawing.Color.Red;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                lblMensaje.Text = "Error al iniciar sesión: " + ex.Message;
                lblMensaje.ForeColor = System.Drawing.Color.Red;
            }
        }

    }
}
