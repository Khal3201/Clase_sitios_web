﻿using System;
using System.Web.UI;

namespace Cafetería
{
    public partial class registro : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            // Aquí podrías cargar algo al inicio si lo necesitas
        }

        protected void btnRegistrar_Click(object sender, EventArgs e)
        {
            // Obtener datos del formulario
            string nombre = txtNombre.Text.Trim();
            string correo = txtCorreo.Text.Trim();
            string contrasena = txtContrasena.Text.Trim();

            // Validar que no estén vacíos (puedes hacer validaciones más avanzadas)
            if (string.IsNullOrEmpty(nombre) || string.IsNullOrEmpty(correo) || string.IsNullOrEmpty(contrasena))
            {
                lblMensaje.Text = "Por favor, completa todos los campos.";
                lblMensaje.ForeColor = System.Drawing.Color.Red;
                return;
            }

            // Aquí podrías guardar en base de datos
            // Por ahora mostramos un mensaje de éxito
            lblMensaje.Text = "Usuario registrado exitosamente.";
            lblMensaje.ForeColor = System.Drawing.Color.Green;

            // Limpiar campos (opcional)
            txtNombre.Text = "";
            txtCorreo.Text = "";
            txtContrasena.Text = "";
        }

        protected void txtNombre_TextChanged(object sender, EventArgs e)
        {

        }

        protected void txtCorreo_TextChanged(object sender, EventArgs e)
        {

        }

        protected void txtContrasena_TextChanged(object sender, EventArgs e)
        {

        }

        protected void txtCorreoLogin_TextChanged(object sender, EventArgs e)
        {

        }

        protected void txtContrasenaLogin_TextChanged(object sender, EventArgs e)
        {

        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {

        }
    }
}
